/*! elementor - v3.15.0 - 20-08-2023 */
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
/*!*********************************************************!*\
  !*** ../core/editor/assets/js/editor-environment-v2.js ***!
  \*********************************************************/


var _window$__UNSTABLE__e;
if (!((_window$__UNSTABLE__e = window.__UNSTABLE__elementorPackages) !== null && _window$__UNSTABLE__e !== void 0 && _window$__UNSTABLE__e.env)) {
  throw new Error('The "@elementor/env" package was not loaded.');
}
window.__UNSTABLE__elementorPackages.env.initEnv(window.elementorEditorV2Env);
/******/ })()
;
//# sourceMappingURL=editor-environment-v2.js.map